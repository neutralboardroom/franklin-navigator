#!/usr/bin/env bash
set -euo pipefail

RELEASE='FR-NAV0.7.0-CANDIDATE-R22'
BASE='8ffa7a9dd935e8763f1ca7fd731d98b6b38d4d79'
UPLOAD='/tmp/r22-upload'
EXPECTED_DIST_TAR_SHA='3f9d413b6d9ec599c769e8b0c124f2d18a01d0ee145c0cd4a45b889e76a36549'

# Stage must descend from the exact live R21 production commit.
test "$(git merge-base HEAD "$BASE")" = "$BASE"
test "$(git rev-parse origin/main)" = "$BASE"

# Verify compact payload controls.
echo 'd5653a6ee2cbab93543642d0ea1f087e988ee883a6c6a3074af33e28ba3316e8  /tmp/r22-upload/r22-dist.tar.zst' | sha256sum -c -
echo '32e7f27c276e2c731f604ddd64ee1f1bb7198effa72969b97e223c6be06253e3  /tmp/r22-upload/PRODUCTION_RELEASE.json' | sha256sum -c -
echo '145210ed980dce89e728c4690d654b0783f1ef2424f0aedcad385826013a9f53  /tmp/r22-upload/README.md' | sha256sum -c -

# Expand and prove the exact sealed public tree before touching Git state.
zstd -q -dc "$UPLOAD/r22-dist.tar.zst" > /tmp/r22-dist.tar
echo "$EXPECTED_DIST_TAR_SHA  /tmp/r22-dist.tar" | sha256sum -c -
rm -rf dist
tar -xf /tmp/r22-dist.tar

test "$(find dist -type f -name '*.html' | wc -l)" -eq 19275
test "$(find dist/profiles -mindepth 2 -maxdepth 2 -type f -name index.html | wc -l)" -eq 19103
grep -q 'FR-NAV0.7.0-CANDIDATE-R22' dist/release-identity.json

echo 'bbec2a38bcf59b12cea93ac5b4a7597b445048e5bd07d8674492a33f09a58cbe  dist/sitemap.xml' | sha256sum -c -
echo 'f1c137c6ea67568bc14d827914beb1525d845aea9f10fe33398e3145094c62c3  dist/index.html' | sha256sum -c -
echo 'b1584d827ba31d55153fb17069653db1b8e065abf486c41c8ac490b44a61c75a  dist/FRANKLIN_BUILD_MANIFEST.json' | sha256sum -c -

# Recreate the deterministic public tar as a final byte-level gate.
find dist -type d -exec chmod 755 {} +
find dist -type f -exec chmod 644 {} +
tar --sort=name --mtime='UTC 1970-01-01' --owner=0 --group=0 --numeric-owner -cf /tmp/r22-dist-verify.tar dist
echo "$EXPECTED_DIST_TAR_SHA  /tmp/r22-dist-verify.tar" | sha256sum -c -

cp "$UPLOAD/PRODUCTION_RELEASE.json" PRODUCTION_RELEASE.json
cp "$UPLOAD/README.md" README.md
rm -f FRANKLIN_R22__GITHUB_DEPLOY_PAYLOAD.zip
rm -f .github/workflows/expand-r22.yml

git config user.name 'Franklin Navigator Release Bot'
git config user.email 'actions@users.noreply.github.com'
git add -A
git commit -m 'Deploy Franklin Navigator R22 exact verified payload'
git push origin HEAD:r22-production-stage
